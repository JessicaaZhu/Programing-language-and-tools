//
//  part1.h
//  lab5
//
//  Created by yuejing zhu on 2017/11/2.
//  Copyright © 2017年 yuejing. All rights reserved.
//

#ifndef part1_h
#define part1_h

#include <stdio.h>
#include <stdlib.h>
#define jedifirstlen 2
#define jedilastlen 3



int strlength(char haystack[]);
char * jedi(char *firstname, char *lastname, char *buffer);
#endif /* part1_h */
