//
//  partA.h
//  lab4
//
//  Created by yuejing zhu on 2017/10/24.
//  Copyright © 2017年 yuejing. All rights reserved.
//

#ifndef partA_h
#define partA_h

#include <stdio.h>
int strlength(char haystack[]);
int myStrStr (char haystack[], char needle[], char buffer[]);

#endif /* partA_h */
